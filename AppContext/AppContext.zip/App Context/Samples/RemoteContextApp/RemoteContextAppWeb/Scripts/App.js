﻿'use strict';
window.Wingtip = window.Wingtip || {}

$(document).ready(function () {

    $.when(Wingtip.RemoteContextInfo.init_base(), Wingtip.RemoteContextInfo.init_user(), Wingtip.RemoteContextInfo.init_location()).done(
        function() {
            ko.applyBindings(Wingtip.RemoteContextInfo, document.getElementById("contextTable"));
        }
    );
    
});

