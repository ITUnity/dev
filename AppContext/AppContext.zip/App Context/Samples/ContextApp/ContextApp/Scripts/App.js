﻿'use strict';
window.Wingtip = window.Wingtip || {}

$(document).ready(function () {

    $.when(Wingtip.ContextInfo.init_base(), Wingtip.ContextInfo.init_user(), Wingtip.ContextInfo.init_location()).done(
        function () {
            ko.applyBindings(Wingtip.ContextInfo, document.getElementById("contextTable"));
        }
    );

});

