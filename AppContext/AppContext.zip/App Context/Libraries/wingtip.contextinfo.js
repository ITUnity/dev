﻿"use strict";

window.Wingtip = window.Wingtip || {}

Wingtip.ContextInfo = function () {

    var context,

        get_context = function () {
            if (typeof window.sessionStorage === 'undefined') {
                return context;
            }
            else {
                return JSON.parse(window.sessionStorage.getItem('AppContextObject'));
            }
        },

        set_context = function (v) {
            if (typeof window.sessionStorage === 'undefined') {
                v.SessionStorageSupport = false;
                context = v;
            }
            else {
                v.SessionStorageSupport = true;
                window.sessionStorage.setItem('AppContextObject', JSON.stringify(v));
            }
        },

        init = function () {
            $.when(Wingtip.ContextInfo.init_base(), Wingtip.ContextInfo.init_user(), Wingtip.ContextInfo.init_location()).then(
               function () {
                   ko.applyBindings(Wingtip.ContextInfo, document.getElementById("contextTable"));
               },
                function () {
                    ko.applyBindings(Wingtip.ContextInfo, document.getElementById("contextTable"));
                }
            );
        },

        init_base = function () {

            var deferred = new $.Deferred();

            //Create a new context object
            var tempContext = {
                "ContextCreated": new Date(),
                "ContextModified": new Date(),
                "SessionStorageSupport": "undefined",
                "BaseContextStatus": "undefined",
                "SiteFullUrl": "undefined",
                "WebFullUrl": "undefined",
                "AppQueryString": "undefined",
                "SPHostUrl": "undefined",
                "SPAppWebUrl": "undefined",
                "SPLanguage": "undefined",
                "SPClientTag": "undefined",
                "SPProductNumber": "undefined",
                "SenderId": "undefined",
                "FormDigest": "undefined",
                "FormDigestTimeout": "undefined",
                "FormDigestValid": false,
                "SPLibraryVersion": "undefined",
                "GeoLocationStatus": "undefined",
                "GeoLocationValid": false,
                "Latitude": "undefined",
                "Longitude": "undefined",
                "UserContextStatus": "undefined",
                "LoginName": "undefined",
                "DisplayName": "undefined",
                "Email": "undefined"
            };
            set_context(tempContext);

            //Base context information
            get_spContextInfo().then(
                function (data) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.BaseContextStatus = "success";
                    tempContext.SiteFullUrl = data.d.GetContextWebInformation.SiteFullUrl;
                    tempContext.WebFullUrl = data.d.GetContextWebInformation.WebFullUrl;
                    tempContext.AppQueryString = window.location.search.substring(1).split("&");
                    tempContext.SPHostUrl = get_queryStringValue("SPHostUrl");
                    tempContext.SPAppWebUrl = get_queryStringValue("SPAppWebUrl");
                    tempContext.SPLanguage = get_queryStringValue("SPLanguage");
                    tempContext.SPClientTag = get_queryStringValue("SPClientTag");
                    tempContext.SPProductNumber = get_queryStringValue("SPProductNumber");
                    tempContext.SenderId = get_queryStringValue("senderId");
                    tempContext.FormDigestTimeout = data.d.GetContextWebInformation.FormDigestTimeoutSeconds * 1000;
                    tempContext.FormDigest = data.d.GetContextWebInformation.FormDigestValue;
                    tempContext.FormDigestValid = true;
                    tempContext.SPLibraryVersion = data.d.GetContextWebInformation.LibraryVersion;
                    set_context(tempContext);
                    window.setTimeout(invalidateFormDigest, tempContext.FormDigestTimeout);
                    deferred.resolve();
                },
                function (err) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.BaseContextStatus = JSON.stringify(err);
                    tempContext.SiteFullUrl = "undefined";
                    tempContext.WebFullUrl = "undefined";
                    tempContext.AppQueryString = "undefined";
                    tempContext.SPHostUrl = "undefined";
                    tempContext.SPLanguage = "undefined";
                    tempContext.SPClientTag = "undefined";
                    tempContext.SPProductNumber = "undefined";
                    tempContext.SPAppWebUrl = "undefined"
                    tempContext.SenderId = "undefined";
                    tempContext.FormDigestTimeout = "undefined";
                    tempContext.FormDigest = "undefined";
                    tempContext.FormDigestValid = false;
                    set_context(tempContext);
                    deferred.resolve();
                }
            );

            return deferred.promise();
        },

        init_user = function () {

            var deferred = $.Deferred();

            //User Information
            get_userProperties().then(
                function (data) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.UserContextStatus = "success";
                    tempContext.LoginName = data.d.LoginName;
                    tempContext.DisplayName = data.d.Title;
                    tempContext.Email = data.d.Email;
                    set_context(tempContext);
                    deferred.resolve();
                },
                function (err) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.UserContextStatus = JSON.stringify(err);
                    tempContext.LoginName = "undefined";
                    tempContext.DisplayName = "undefined";
                    tempContext.Email = "undefined";
                    set_context(tempContext);
                    deferred.resolve();
                }
            );

            return deferred.promise();
        },

        init_location = function () {

            var deferred = $.Deferred();

            //Geolocation Information
            get_location().then(
                function (data) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.GeoLocationStatus = 'Success';
                    tempContext.GeoLocationValid = true;
                    tempContext.Latitude = data.coords.latitude;
                    tempContext.Longitude = data.coords.longitude;
                    set_context(tempContext);
                    deferred.resolve();
                },
                function (err) {
                    var tempContext = get_context();
                    tempContext.ContextModified = new Date();
                    tempContext.GeoLocationValid = false;
                    tempContext.Latitude = 'undefined';
                    tempContext.Longitude = 'undefined';
                    switch (err.code) {
                        case 1:
                            tempContext.GeoLocationStatus = 'Permission denied.';
                            break;
                        case 2:
                            tempContext.GeoLocationStatus = 'Position unavailable';
                            break;
                        case 3:
                            tempContext.GeoLocationStatus = 'Operation timed out';
                            break;
                        default:
                            tempContext.GeoLocationStatus = 'Unknown error';
                            break;
                    }
                    set_context(tempContext);
                    deferred.resolve();
                }
            );

            return deferred.promise();
        },

        get_spContextInfo = function () {
            var promise = $.ajax({
                url: "../_api/contextinfo",
                type: "POST",
                headers: {
                    "accept": "application/json;odata=verbose",
                }
            });
            return promise;
        },

        get_userProperties = function () {

            var promise = $.ajax({
                url: "../_api/web/currentUser",
                type: "GET",
                headers: {
                    "accept": "application/json;odata=verbose",
                }
            });
            return promise;
        },

        get_queryStringValue = function (name) {
            try {
                var args = window.location.search.substring(1).split("&");
                var r = "";
                for (var i = 0; i < args.length; i++) {
                    var n = args[i].split("=");
                    if (n[0] == name)
                        r = decodeURIComponent(n[1]);
                }
                return r;
            }
            catch (err) {
                return 'undefined';
            }
        },

        get_location = function () {
            var deferred = $.Deferred();
            if (typeof navigator.geolocation === 'undefined') {
                context.GeoLocationValid = false;
                context.Latitude = 'undefined';
                context.Longitude = 'undefined';
                context.GeoLocationStatus = 'Position Not Available';
            }
            else {
                navigator.geolocation.getCurrentPosition(
                    function (data) { deferred.resolve(data); },
                    function (err) { deferred.reject(err); }
                );
            }
            return deferred.promise();
        },

        invalidateFormDigest = function () {
            var tempContext = get_context();
            tempContext.ContextModified = new Date();
            tempContext.FormDigestValid = false;
            set_context(tempContext);
        };

    return {
        init_base: init_base,
        init_user: init_user,
        init_location: init_location,
        get_context: get_context
    };

}();

