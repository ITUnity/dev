﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.Office.Server;
using Microsoft.Office.Server.Search;
using Microsoft.Office.Server.Search.Query;
using Microsoft.Office.Server.Search.Administration;

namespace Hillier.Navigation.DelegateElements
{
    public class DelegateNavPart : WebControl
    {
        const string queryString = "SELECT url, title " +
                     "FROM Scope() " +
                     "WHERE \"scope\" = 'All Sites' " +
                     "AND contentclass = 'STS_Site'";

        DropDownList portalList;

        protected override void OnLoad(EventArgs e)
        {
            this.EnsureChildControls();
            
            if (!Page.IsPostBack)
            {

                SearchServiceApplicationProxy proxy = (SearchServiceApplicationProxy)SearchServiceApplicationProxy.GetProxy(SPServiceContext.GetContext(SPContext.Current.Site));
                FullTextSqlQuery keywordQuery = new FullTextSqlQuery(proxy);
                keywordQuery.ResultsProvider = SearchProvider.Default;
                keywordQuery.ResultTypes = ResultType.RelevantResults;
                keywordQuery.EnableStemming = false;
                keywordQuery.TrimDuplicates = true;
                keywordQuery.QueryText = queryString;

                ResultTableCollection results = keywordQuery.Execute();
                ResultTable result = results[ResultType.RelevantResults];

                portalList.Items.Add(new ListItem() { Selected = true, Text = "Select a portal", Value = "#" });

                List<PortalNavNode> portals = new List<PortalNavNode>();

                if (result.RowCount > 0)
                {
                    while (result.Read())
                    {
                        portals.Add(new PortalNavNode() { Title = result.GetString(1), Url = result.GetString(0) });
                    }
                }

                var q = from p in portals
                        orderby p.Title
                        select p;

                foreach (var i in q)
                {
                    portalList.Items.Add(new ListItem() { Selected = false, Text = i.Title, Value = i.Url });
                }
            }
        }

        protected override void CreateChildControls()
        {
            this.EnableViewState = true;

            portalList = new DropDownList();
            portalList.AutoPostBack = true;
            portalList.EnableViewState = true;
            portalList.SelectedIndexChanged += new System.EventHandler(portalList_SelectedIndexChanged);
            this.Controls.Add(portalList);
        }

        void portalList_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            SPUtility.Redirect(portalList.SelectedItem.Value, SPRedirectFlags.Trusted, HttpContext.Current);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.Write("<div id=\"DelegateNavDivMain\" style=\"text-align:right;width=100%;background:#21344a\">");
            portalList.RenderControl(writer);
            writer.Write("</div>");
        }
    }

    public class PortalNavNode
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
